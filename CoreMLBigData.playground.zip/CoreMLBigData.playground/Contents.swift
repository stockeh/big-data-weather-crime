import Cocoa
import CreateML
import CreateMLUI

let bookTable1 = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Boulderc30/Desktop/Xcodecsv/wc1-c1.csv"))
let (trainData1, testingData1) = bookTable1.randomSplit(by: 0.5, seed: 0)
let classifier1 = try MLBoostedTreeRegressor(trainingData: bookTable1, targetColumn: "c1", parameters: .init(maxIterations: 10))

let bookTable2 = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Boulderc30/Desktop/Xcodecsv/wc1-c2.csv"))
let (trainData2, testingData2) = bookTable2.randomSplit(by: 0.5, seed: 0)
let classifier2 = try MLBoostedTreeRegressor(trainingData: bookTable2, targetColumn: "c2", parameters: .init(maxIterations: 10))

let bookTable3 = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Boulderc30/Desktop/Xcodecsv/wc1-c3.csv"))
let (trainData3, testingData3) = bookTable3.randomSplit(by: 0.5, seed: 0)
let classifier3 = try MLBoostedTreeRegressor(trainingData: bookTable3, targetColumn: "c3", parameters: .init(maxIterations: 10))

let bookTable4 = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Boulderc30/Desktop/Xcodecsv/wc1-c4.csv"))
let (trainData4, testingData4) = bookTable4.randomSplit(by: 0.5, seed: 0)
let classifier4 = try MLBoostedTreeRegressor(trainingData: bookTable4, targetColumn: "c4", parameters: .init(maxIterations: 10))

let bookTable5 = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Boulderc30/Desktop/Xcodecsv/wc1-c5.csv"))
let (trainData5, testingData5) = bookTable5.randomSplit(by: 0.5, seed: 0)
let classifier5 = try MLBoostedTreeRegressor(trainingData: bookTable5, targetColumn: "c5", parameters: .init(maxIterations: 10))

let bookTable6 = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Boulderc30/Desktop/Xcodecsv/wc1-c6.csv"))
let (trainData6, testingData6) = bookTable6.randomSplit(by: 0.5, seed: 0)
let classifier6 = try MLBoostedTreeRegressor(trainingData: bookTable6, targetColumn: "c6", parameters: .init(maxIterations: 10))

let bookTable7 = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Boulderc30/Desktop/Xcodecsv/wc1-c7.csv"))
let (trainData7, testingData7) = bookTable7.randomSplit(by: 0.5, seed: 0)
let classifier7 = try MLBoostedTreeRegressor(trainingData: bookTable7, targetColumn: "c7", parameters: .init(maxIterations: 10))

let bookTable8 = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Boulderc30/Desktop/Xcodecsv/wc1-c8.csv"))
let (trainData8, testingData8) = bookTable8.randomSplit(by: 0.5, seed: 0)
let classifier8 = try MLBoostedTreeRegressor(trainingData: bookTable8, targetColumn: "c8", parameters: .init(maxIterations: 10))
